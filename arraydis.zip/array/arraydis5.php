<?php

$data = "Tokyo, Japan; Mexico City, Mexico; New York City, USA; Mumbai, India; Seoul, Korea; Shanghai, China; Lagos, Nigeria; Buenos Aires, Argentina; Cairo, Egypt; London, England";
    
$countries = explode(";",$data);
$capitals = [];

foreach ($countries as $pais){

    $countryData = explode(",",$pais);
    $countrycity["country"]  = $countryData[1];
    $countrycity["city"]=  $countryData[0];
    array_push($capitals , $countrycity);
    
}

var_dump($capitals);

?>
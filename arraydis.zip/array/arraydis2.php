<?php

$city = "Japan,Mexico,USA,India,Korea,China,Nigeria,Argentina,Egypt,England";
$cityArray = explode(",",$city);
$capitals = [];
for ($i = 0; $i < count($cityArray); $i++) {
    $countryCity["city"] = $cityArray[$i];
    array_push($capitals, $countryCity);
}

var_dump($capitals);

    




?>